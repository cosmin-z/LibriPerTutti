

<?php
include 'header.php';
?>

<title>LPT &middot; Risultati</title>

    <div class="container mt-5">
        <h4 class="offset-3"> Siamo spiacenti non abbiamo trovato nulla... <img class="ml-3" src="immagini/puzzled.gif"> </h4>
        <img   class="rounded mx-auto d-block gif" src="immagini/torcia.gif" width="" height="" alt="Torcia">
    </div>

</div>

<?php
include 'footer.php';
?>
