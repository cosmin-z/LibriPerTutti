<div class="container">

    <div class="row mt-5" >

        <div class="col-md-1 offset-3 " >
            <img  class="rounded float-left" width="100%" src="immagini/email.png" alt="immagineCartolina">
        </div>

        <div class="col-md-5 mt-2">
            <h5>Hey! hai qualche problema? usa questa mail per contattarci! <a href="mailto:tua@email.com">moderatori@lpt.altervista.org</a></h5>
        </div>

    </div>

<div class="text-center  pb-3 mt-5">
    <hr width="100%">
    <i>
        © 2020 Copyright: Cosmin & Maria Vittoria - Libri per tutti
    </i>
</div>

</div>

<script type="text/javascript" lang="javascript" src="js/main.js"></script>

</body>
</html>
